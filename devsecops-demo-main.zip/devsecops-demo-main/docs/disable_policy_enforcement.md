## Disable the Policy Enforcement

To disable the policy enforcement you need to:

- Go to the ACS Console 
- Platform Configuration Tab
- System Policies
- Fixable CVSS >= 7 
- Edit -> Next -> Next -> Next 
- Build and Deploy into Enforcement Behavior Off