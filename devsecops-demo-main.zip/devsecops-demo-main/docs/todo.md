## TODO

- Add documentation about triggers
- Add better branching with GitHub Flow model
- Update images for the infra (nexus, gogs, etc) with the latest versions
- Use Nexus Operator
- Use Quay Operator and Clair
